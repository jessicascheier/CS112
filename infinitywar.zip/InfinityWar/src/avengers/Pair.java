package avengers;

public class Pair {
    public int key, val;
    public Pair (int key, int val) {
        this.key = key;
        this.val = val;
    }
}
